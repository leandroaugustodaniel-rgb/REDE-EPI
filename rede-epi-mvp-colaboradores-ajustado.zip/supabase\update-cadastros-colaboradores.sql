insert into public.departments (name)
values ('Compras'), ('Comercial'), ('Estoque')
on conflict (name) do nothing;

update public.departments
set name = 'Estoque'
where name in ('Logistica', 'Logística');

insert into public.roles (name)
values
  ('Gerente de Operações'),
  ('Supervisor Comercial'),
  ('Vendedor 1C'),
  ('Vendedor 2A'),
  ('Vendedor 2B'),
  ('Vendedor 2C'),
  ('Vendedor 3A'),
  ('Vendedor 3B'),
  ('Vendedor 3C'),
  ('Assistente Administrativo'),
  ('Supervisor de Compras'),
  ('Analista de Compras Junior'),
  ('Analista de Compras Pleno'),
  ('Analista de Compras Sênior'),
  ('Coordenador do Estoque'),
  ('Encarregado do Estoque'),
  ('Analista da Logística'),
  ('Auxiliar de Estoque Junior'),
  ('Auxiliar de Estoque Pleno'),
  ('Auxiliar de Estoque Sênior'),
  ('Motorista Junior'),
  ('Motorista Pleno'),
  ('Motorista Sênior')
on conflict (name) do nothing;

update public.roles set name = 'Gerente de Operações' where name = 'Gerente de Operacoes';
update public.roles set name = 'Analista de Compras Sênior' where name = 'Analista de Compras Senior';
update public.roles set name = 'Analista da Logística' where name = 'Analista da Logistica';
update public.roles set name = 'Auxiliar de Estoque Sênior' where name = 'Auxiliar de Estoque Senior';
update public.roles set name = 'Motorista Sênior' where name = 'Motorista Senior';

insert into public.units (name, city)
values
  ('REDE - GO', 'Goiania'),
  ('REDE - DF', 'Brasilia'),
  ('REDE - MT', 'Cuiaba'),
  ('REDE - LABOR', 'Laboratorio')
on conflict (name) do nothing;

insert into public.employees
  (name, email, department_id, role_id, unit_id, notes)
select x.name, x.email, d.id, r.id, u.id, 'Lideranca REDE EPI'
from (
  values
    ('Leandro Daniel', 'leandro.daniel@redeepi.com', 'Comercial', 'Gerente de Operações', 'REDE - GO'),
    ('Gabriela Andrade', 'gabriela.andrade@redeepi.com', 'Comercial', 'Supervisor Comercial', 'REDE - GO'),
    ('Cléber Rubeo', 'cleber.rubeo@redeepi.com', 'Comercial', 'Supervisor Comercial', 'REDE - GO'),
    ('Tercio Baldino', 'tercio.baldino@redeepi.com', 'Estoque', 'Coordenador do Estoque', 'REDE - GO'),
    ('Paulo Carvalho', 'paulo.carvalho@redeepi.com', 'Estoque', 'Coordenador do Estoque', 'REDE - GO'),
    ('Priscill Jordão', 'priscill.jordao@redeepi.com', 'Compras', 'Supervisor de Compras', 'REDE - GO')
) as x(name, email, department, role, unit)
join public.departments d on d.name = x.department
join public.roles r on r.name = x.role
join public.units u on u.name = x.unit
on conflict (email) do update set
  name = excluded.name,
  department_id = excluded.department_id,
  role_id = excluded.role_id,
  unit_id = excluded.unit_id,
  notes = excluded.notes;
